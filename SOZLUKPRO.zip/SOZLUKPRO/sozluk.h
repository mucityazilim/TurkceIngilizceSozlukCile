#ifndef _SOZLUK_H
#define _SOZLUK_H

typedef struct Sozluk {
	char turkce[20], ingilizce[20]; 
} sozluk ;

void kelimeEkle(); 

	void turkceIngilizce(); 
	void ingilizceTurkce(); 
	
void kelimeBul(); 
void kelimeListele(); 
void kelimeSil(); 

int menu() ; 
void sozlukIslemleri();

#endif 

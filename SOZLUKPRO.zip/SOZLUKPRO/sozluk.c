#include "sozluk.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

sozluk soz; 

void kelimeEkle()
{
	system("cls")  ; 
	printf("\nKelime ekleme ekrani \n\n"); 
	printf("Turkce Kelime     :  "); scanf(" %[^\n]s", soz.turkce ); 
	printf("Ingilizce Kelime  :  "); scanf(" %[^\n]s", soz.ingilizce );	
	strlwr(soz.turkce); 
	strlwr(soz.ingilizce); 
	
	FILE *ptr = fopen("sozluk.dat","a+b") ; 
	fwrite (&soz, sizeof(sozluk), 1, ptr ) ; 
	fclose(ptr) ; 
	printf("Kelime kaydi tamam \n") ; 
					
} 


void turkceIngilizce()
{
	system("cls")  ; 
	printf("\nTurkce - Ingilizce ekrani \n\n"); 
	char kelime[20]; 
	printf("Turkce Kelime     :  "); scanf(" %[^\n]s", kelime  );
	strlwr(kelime ) ;                                 // kullan�c� b�y�k harfle girme ihtimali nedeniyle kelimeyi k���k harfe d�n��t�rd�k
	
	int sonuc=0; 	
	FILE *ptr = fopen("sozluk.dat","r+b") ; 
	while( fread  (&soz, sizeof(sozluk), 1, ptr ) !=NULL  )
	{
		if( strcmp( kelime, soz.turkce ) ==0 ) 
		{
		printf("\n\n%-20s%-20s\n", soz.turkce, soz.ingilizce );
		sonuc= 1; 
		break; 			
		} 
	}
	fclose(ptr) ; 
	if(sonuc==0)
	printf("\n\n\nMelesef karsiligi yok !!!\n"); 
		
 } 
void ingilizceTurkce()
{
	system("cls")  ; 
	printf("\nIngilizce - Turkce  ekrani \n\n"); 
	char kelime[20]; 
	printf("Ingilizce Kelime     :  "); scanf(" %[^\n]s", kelime  );
	strlwr(kelime ) ; // kullan�c� b�y�k harfle girme ihtimali nedeniyle kelimeyi k���k harfe d�n��t�rd�k
	
	int sonuc=0; 
	
	FILE *ptr = fopen("sozluk.dat","r+b") ; 
	while( fread  (&soz, sizeof(sozluk), 1, ptr ) !=NULL  )
	{
		if( strcmp( kelime, soz.ingilizce ) ==0 ) 
		{
		printf("\n\n%-20s%-20s\n"  , soz.ingilizce, soz.turkce );
		sonuc= 1; 
		break; 			
		} 
	}
	fclose(ptr) ; 
	if(sonuc==0)
	printf("\n\n\nMelesef karsiligi yok !!!\n"); 
	
}


void kelimeBul()
{

	system("cls")  ; 
	int secim= 
	
	printf("\nKelime bulma  ekrani \n\n"); 
	printf("1-Turkce    - Ingilizce \n") ; 
	printf("2-Ingilizce - Turkce  \n") ; 
	printf("0-Cikis \n") ;
	printf("seciminiz : ") ; scanf("%d", &secim);  
	
	if( secim ==1)
	turkceIngilizce(); 
	else if( secim ==2)
	ingilizceTurkce(); 
	else if(secim ==0) 
	printf("Ana menuye yonlendiriliyorsunuz... \n\n") ; 
	else 
	printf("Hatali secim yaptiniz !\n") ; 	 
	
	
}
void kelimeListele()
{
	system("cls")  ; 
	printf("\nKelime listeleme ekrani \n\n"); 
	int sayac=0; 
		
	printf("%-10s%-20s%-20s\n","Sira No",  "TURKCE", "INGILIZCE" ); 
	
	FILE *ptr = fopen("sozluk.dat","r+b") ; 
	while( fread  (&soz, sizeof(sozluk), 1, ptr ) !=NULL  )
	{
		sayac++;
		printf("%-10d%-20s%-20s\n", sayac, soz.turkce, soz.ingilizce );
		 
	}
	fclose(ptr) ; 
	if(sayac==0)
	printf("\n\n\nHer hangi bir kelime kaydi yok !\n"); 
	else
	printf("\n\n\nToplam kelime sayisi :  %d \n", sayac )  ;	
	
}
void kelimeSil() 
{
	system("cls")  ; 
	int sayac=0, siraNo; 
		
	printf("%-10s%-20s%-20s\n","Sira No",  "TURKCE", "INGILIZCE" ); 
	
	FILE *ptr = fopen("sozluk.dat","r+b") ; 
	while( fread  (&soz, sizeof(sozluk), 1, ptr ) !=NULL  )
	{
		sayac++;
		printf("%-10d%-20s%-20s\n", sayac, soz.turkce, soz.ingilizce );
		 
	}

	if(sayac==0)
	printf("\n\n\nHer hangi bir kelime kaydi yok !\n"); 
	else
	{
		printf("\nSilmek istediginiz kelimenin sira nosu   : "); scanf("%d", &siraNo) ;  
		if( siraNo <0 || siraNo >sayac  ) 
		printf("Hatali numara girdiniz !!! \n") ; 
		else
		{
			sayac=0; 
			rewind(ptr); 
			FILE *yedekPtr= fopen("yedek.dat","w+b" ) ; 
			while( fread  (&soz, sizeof(sozluk), 1, ptr ) !=NULL  )
			{
				sayac++; 								
				if( siraNo != sayac  ) 
				{
					fwrite  (&soz, sizeof(sozluk), 1, yedekPtr ) ;					
				} 
				 
			}
			fclose(ptr); 
			fclose(yedekPtr) ; 
			remove("sozluk.dat") ; 
			rename("yedek.dat", "sozluk.dat") ; 
			printf("Silma islemi tamam \n" ) ; 
		}
		
	
	}
		fclose(ptr) ;  
	
	
}
int menu() 
{
	int secim; 
	printf("\n\n\n\t\tTURKCE-INGILIZCE SOZLUK PROGRAMI \n\n\n") ; 
	printf("\t\t\t1-KELIME EKLE \n\n") ; 
	printf("\t\t\t2-KELIME BUL \n\n") ;
	printf("\t\t\t3-KELIME LISTELE \n\n") ;
	printf("\t\t\t4-KELIME SIL \n\n") ;	 		
	printf("\t\t\t0- CIKIS \n\n") ; 
	printf("\t\t\tSeciminiz : " ) ; scanf("%d", &secim); 	
	system("cls") ; 
	return secim; 
}
void sozlukIslemleri()
{
	int secim= menu(); 
	while( secim != 0)
	{
		switch(secim )
		{
			case 1: kelimeEkle (); break; 
			case 2: kelimeBul (); break; 
			case 3: kelimeListele (); break; 
			case 4: kelimeSil (); break;
			case 0: break; 
			default : printf("Hatali secim ! \n") ; 
		}
		secim= menu(); 
	} 	
}


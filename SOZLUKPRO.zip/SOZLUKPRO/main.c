#include <stdio.h>
#include <stdlib.h>
#include "sozluk.h" 
// T�rk�e - Ingilizce S�zl�k Program� 
// Mucit Yaz�l�m - Sad�k �AH�N

int main(int argc, char *argv[]) {
	
	sozlukIslemleri(); 	
	
	
	return 0;
}
